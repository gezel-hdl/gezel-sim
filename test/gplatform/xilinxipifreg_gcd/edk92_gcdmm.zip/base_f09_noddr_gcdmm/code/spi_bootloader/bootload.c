/*-----------------------------------------------------------------------------
//
//     AVNET IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, AVNET IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  AVNET EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2005 AVNET, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/

//***************************************************************************//
//
// File:         bootload.c
// Date:         November 14, 2005
// Created by:   Matthew O'Meara
//               Bryan Fletcher
// Description:  BRAM-based bootloader.  Copies a binary application from SPI
//               flash to external memory, then jumps to that memory
//
//***************************************************************************//

//**************** INCLUDES *************************************************//
#include "xparameters.h"
#include "xbasic_types.h"
#include "xspi_l.h"
#include "SF_commands.h"

//**************** CONSTANTS ************************************************//
#define DESTINATION_ADDR      XPAR_DDR_SDRAM_MPMC_BASEADDR
#define BOOT_SECTOR           6        // 6*256pages/sector*256bytes/page = 393216 = 0x60000

#define WORDS_TO_COPY         0x10000  // Corresponds to maximum program size.  0x10000 = 64KB.
                                       // 64KB is copied from SPI flash to external memory
#define SCK_FASTER_THAN_20MHz 1        // Determines whether READ or FAST_READ is used

//**************** GLOBALS **************************************************//
unsigned char my_send[16];
unsigned char my_receive[16];

//**************** PROTOTYPES ***********************************************//
int (*boot_app) (void);

//***************************************************************************//
int main (void) {

  Xint32  spi_status;
  Xint32  int_enable;

  Xuint16 Control;
  Xint32  NumBytesSent = 0;
  Xint32  NumBytesRcvd = 0;

  Xuint16 i, k;
  Xuint8  status_byte, busy;
  Xint32  ready_busy;
  Xuint8* destination_location = (unsigned char *) DESTINATION_ADDR;

  //*************** DEVICE INITIALIZATION ***************************//
   /*
    * Enable and initialize cache
    */
   #if XPAR_MICROBLAZE_0_USE_ICACHE
      microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
      microblaze_enable_icache();
   #endif

   #if XPAR_MICROBLAZE_0_USE_DCACHE
      microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
      microblaze_enable_dcache();
   #endif

  print("\n\rBooting...");

  // SPI Controller initialization
  Initialize_Spi_Controller(XPAR_SPI_FLASH_BASEADDR);
  XSpi_mEnable(XPAR_SPI_FLASH_BASEADDR);

//====================================================================//

  // Copy WORDS_TO_COPY number of words from Source to Destination
  SF_start_read (XPAR_SPI_FLASH_BASEADDR, BOOT_SECTOR, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  for (i = 0; i < WORDS_TO_COPY/16; i++)
  {
    // Read in 16 bytes at a time
    spi_transfer(my_send, my_receive, 16);
	// Write 16 bytes to destination address
    for (k=0; k<16; k++)
	  *destination_location++ = my_receive[k];
  }
  SF_end_read (XPAR_SPI_FLASH_BASEADDR);
  print("Done!\n\r");

  // Verify file was copied correctly (checking first 2400 bytes)
  destination_location = (unsigned char *) DESTINATION_ADDR;
  SF_start_read (XPAR_SPI_FLASH_BASEADDR, BOOT_SECTOR, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  for (i=0; i<150; i++)
  {
    spi_transfer(my_send, my_receive, 16);
	for (k=0; k<16; k++)
	{
      if (my_receive[k] != *destination_location++)
	  {
	    print("\n\r !ERROR! File not copied correctly\n\r");
        while(1);
      }
    }
  }
  SF_end_read (XPAR_SPI_FLASH_BASEADDR);
  // end Verify

   /*
    * Disable cache and reinitialize it so that other
    * applications can be run with no problems
    */
   #if XPAR_MICROBLAZE_0_USE_DCACHE
      microblaze_disable_dcache();
      microblaze_init_dcache_range(0, XPAR_MICROBLAZE_0_DCACHE_BYTE_SIZE);
   #endif

   #if XPAR_MICROBLAZE_0_USE_ICACHE
      microblaze_disable_icache();
      microblaze_init_icache_range(0, XPAR_MICROBLAZE_0_CACHE_BYTE_SIZE);
   #endif

  // function pointer that is set to point to the address of  
  // DESTINATION_ADDR
  boot_app = (int (*) (void)) DESTINATION_ADDR;
  // jump to start execution code at the address START_ADDR
  boot_app();

  while(1) { ; }

  return 0;
}
