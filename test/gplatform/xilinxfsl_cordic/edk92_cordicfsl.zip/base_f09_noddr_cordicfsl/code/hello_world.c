int secretnumber() {
  int a;
  return (int) &a;
}

int main () {

  xil_printf("\n\rHello World\n\r");
  xil_printf("Hello Mars\n\r");
  xil_printf("Hello Saturnus\n\r");
  xil_printf("Not you, Pluto\n\r");

  xil_printf("The secret number is %x\n", secretnumber());

  return 0;
}
