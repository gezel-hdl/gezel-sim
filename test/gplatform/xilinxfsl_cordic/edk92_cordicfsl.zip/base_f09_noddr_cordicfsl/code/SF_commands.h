//-----------------------------------------------------------------------------
//
//     AVNET IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, AVNET IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  AVNET EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2005 AVNET, Inc.
//     All rights reserved.
//
//-----------------------------------------------------------------------------

//***************************************************************************//
//
// File:         SF_commands.h
// Date:         August 1, 2007
// Created by:   Bryan Fletcher
// Description:  Definitions for SF_commands.c
//               
//***************************************************************************//

#include "xspi_l.h"

// PROTOTYPES
void spi_transfer (unsigned char *send, unsigned char *recv, unsigned char num_bytes);
void poll_until_complete (Xuint32 BaseAddress);
Xuint8 SF_read_status_register (Xuint32 BaseAddress);
void SF_write_status_register (Xuint32 BaseAddress, Xuint8 data);
void SF_write_enable (Xuint32 BaseAddress);
void SF_write_disable (Xuint32 BaseAddress);
void SF_bulk_erase (Xuint32 BaseAddress);
void SF_sector_erase (Xuint32 BaseAddress, Xuint8 sector_address);
void SF_start_page_program (Xuint32 BaseAddress, Xuint8 sector_address, Xuint8 page_address, \
                                Xuint8 page_offset);
void SF_end_page_program (Xuint32 BaseAddress);
void SF_start_read (Xuint32 BaseAddress, Xuint8 sector_address, Xuint8 page_address, \
                        Xuint8 page_offset, Xuint8 speed_setting);
void SF_end_read (Xuint32 BaseAddress);


// DEFINITIONS

//	                    | Sectors  |  Pages/Sector  |  Bytes/Page  |  Total Bytes  |
// Intel 64 Mbit S33    |   128    |      256       |     256      |    8388608    |
// STMicro M25P16       |   32     |      256       |     256      |    2097152    |

#define  SF_SECTORS           32
#define  SF_PAGES_PER_SECTOR  256
#define  SF_BYTES_PER_PAGE    256
#define  SF_BYTES             2097152

// Slave Select Masks
#define  SPI_NONE_SELECT    0xFF
#define  SPI_SELECT_0       0xFE
#define  SPI_SELECT_1       0xFD
#define  SPI_SELECT_2       0xFB
#define  SPI_SELECT_3       0xF7
#define  SPI_SELECT_4       0xEF
#define  SPI_SELECT_5       0xDF
#define  SPI_SELECT_6       0xBF
#define  SPI_SELECT_7       0x7F

#define  SPI_FLASH_SELECT   SPI_SELECT_0

// SF One-byte Op-Codes
#define  WREN    0x06  // Write Enable
#define  WRDI    0x04  // Write Disable
#define  RDID    0x9F  // Read Identification
#define  RDSR    0x05  // Read Status Register
#define  WRSR    0x01  // Write Status Register
#define  READ    0x03  // Read Data Bytes
#define  FAST    0x0B  // Read Data Bytes at Higher Speed
#define  PP      0x02  // Page Program
#define  SE      0xD8  // Sector Erase
#define  BE      0xC7  // Bulk Erase
#define  DP      0xB9  // Deep Power-down
#define  RES     0xAB  // Read 8-bit Electronic Signature and/or Release from Deep power-down

// SF Status Register masks
#define WRITE_IN_PROGRESS_MASK  0x01

// SF Initial Control Reg
#define  INIT_CREG  (XSP_CR_TRANS_INHIBIT_MASK | XSP_CR_MANUAL_SS_MASK | XSP_CR_MASTER_MODE_MASK)
//#define  INIT_CREG  (XSP_CR_MASTER_MODE_MASK)

#define  DUMMY_BYTE 0xAA


//==============================================================================
// Function : Initialize_Spi_Controller(BaseAddress)
//
// Description : Initialize the SPI Controller
//
// Inputs:       BaseAddress
//
//==============================================================================

#define Initialize_Spi_Controller(BaseAddress) \
{ \
  XSpi_mSetControlReg(BaseAddress, INIT_CREG); \
  XSpi_mSetSlaveSelectReg(BaseAddress, SPI_NONE_SELECT); \
}


//==============================================================================
// Function : XSpi_Set_Inhibit(BaseAddress)
//
// Description : Set the transmit inhibit bit
//
// Inputs:       BaseAddress
//
//==============================================================================

#define XSpi_Set_Inhibit(BaseAddress) \
{ \
    Xuint16 Control; \
    Control = XSpi_mGetControlReg((BaseAddress)); \
    Control |= XSP_CR_TRANS_INHIBIT_MASK; \
    XSpi_mSetControlReg((BaseAddress), Control); \
}

//==============================================================================
// Function : XSpi_Clear_Inhibit(BaseAddress)
//
// Description : Set the transmit inhibit bit
//
// Inputs:       BaseAddress
//
//==============================================================================

#define XSpi_Clear_Inhibit(BaseAddress) \
{ \
    Xuint16 Control; \
    Control = XSpi_mGetControlReg((BaseAddress)); \
    Control &= ~XSP_CR_TRANS_INHIBIT_MASK; \
    XSpi_mSetControlReg((BaseAddress), Control); \
}

#define XSpi_Set_Enable(BaseAddress) \
{ \
    Xuint16 Control; \
    Control = XSpi_mGetControlReg((BaseAddress)); \
    Control |= XSP_CR_ENABLE_MASK; \
    XSpi_mSetControlReg((BaseAddress), Control); \
}


