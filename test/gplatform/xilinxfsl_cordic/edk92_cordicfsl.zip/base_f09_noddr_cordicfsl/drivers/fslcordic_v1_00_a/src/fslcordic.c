//////////////////////////////////////////////////////////////////////////////
// Filename:          C:\fpga_designs\f09\base_f09_noddr_cordicfsl\drivers/fslcordic_v1_00_a/src/fslcordic.c
// Version:           1.00.a
// Description:       fslcordic (Cordic module with FSL interface) Driver Source File
// Date:              Wed Aug 12 22:32:33 2009 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////

#include "fslcordic.h"
/*
* Write your driver implementation in this file.
*/

